<div class="prdcts">
  <div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h2 class="prdcts__title">Deals of the Day</h2>
        </div>
        <div class="col-md-6 text-right">
          <button type="button" class="prdcts__allbtn">View all</button>
        </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="prdcts__slider" id="slider1">

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>


          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>


          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>


          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>


          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>


          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>


          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>

          <div class="prdcts__item text-center">
            <div class="img__container">
              <img src={{ asset('images/prdct1.jpg') }} alt="#">
            </div>
            <h4>Products Header</h4>
            <p class="item__price">25,000 BDT</p>
            <p class="item__saler">Mehedi Hassan Durjoi</p>
          </div>
        </div>
        <button class="prdctbtn-left prdctslider-btn slider1-btn-left"><i class="fas fa-chevron-left"></i></button>
        <button class="prdctbtn-right prdctslider-btn slider1-btn-right"><i class="fas fa-chevron-right"></i></button>
      </div>
    </div>
  </div>
</div>
