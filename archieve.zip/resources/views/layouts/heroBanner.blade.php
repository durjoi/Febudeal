<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="hero-bnr">
        <button class="btn-left slider-btn"><i class="fas fa-chevron-left"></i></button>
        <div class="bnr-slider">
          <img src={{ asset('images/slider1.jpg') }} alt="slider1">
          <img src={{ asset('images/slider2.jpg') }} alt="slider2">
          <img src={{ asset('images/slider3.jpg') }} alt="slider3">
        </div>
        <button class="btn-right slider-btn"><i class="fas fa-chevron-right"></i></button>
      </div>
    </div>
  </div>
</div>
