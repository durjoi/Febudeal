<div class="menubar">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3">
        <div class="menubar__logo">
          <h2><a href="<?php echo e(route('index')); ?>">Febudeal</a></h2>
        </div>
      </div>
      <div class="col-md-5">
          <form class="menubar__srcbox" action="#" method="#">
            <input type="text" name="search" class="srcbox__input">
            <button type="submit" name="submit-btn" class="srcbox__btn"><i class="fas fa-search"></i></button>
          </form>
      </div>
      <div class="col-md-4">
        <div class="menubar__menu">
          <ul>
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> Login</a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('register')); ?>"><i class="fas fa-user"></i> Sign Up</a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
            
            <li><a href="#"><i class="fas fa-shopping-cart"></i> Cart</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/layouts/nav.blade.php ENDPATH**/ ?>