<?php $__env->startSection('content'); ?>
    Hello
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/pages/about.blade.php ENDPATH**/ ?>