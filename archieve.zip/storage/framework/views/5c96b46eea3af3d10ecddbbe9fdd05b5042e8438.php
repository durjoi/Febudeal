<?php $__env->startSection('content'); ?>
<div class="row mb-3">
  <div class="col-12 text-center">
    <h2>Saler Register</h2>
  </div>
</div>
<div class="row">
  <div class="col-4 offset-4">
    <form class="student-registration" action="<?php echo e(route('saler.register.submit')); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <table>
        <tr>
          <td>
            <label for="name">Name:</label>
          </td>
          <td>
            <input type="text" name="name" id="name" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </td>
        </tr>
        <tr>
          <td>
            <label for="email">Email:</label>
          </td>
          <td>
            <input type="text" name="email" id="email" required>
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </td>
        </tr>
        <tr>
          <td>
            <label for="password">Password</label>
          </td>
          <td>
            <input type="text" name="password" id="password" required>
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </td>
        </tr>
        <tr>
          <td></td>
          <td>
            <button type="submit" name="button" class="btn btn-success">Submit</button>
          </td>
        </tr>
      </table>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/auth/saler-register.blade.php ENDPATH**/ ?>