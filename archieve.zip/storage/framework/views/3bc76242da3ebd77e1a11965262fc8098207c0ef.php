<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
<?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/pertials/styles.blade.php ENDPATH**/ ?>