  <nav>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4">
          <h2>Febudeal Admin</h2>
        </div>
        <div class="col-md-8 text-right">
          <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><button type="button" name="button">Log out</button></a> </li>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </div>
      </div>
    </div>
  </nav>
<?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminNav.blade.php ENDPATH**/ ?>