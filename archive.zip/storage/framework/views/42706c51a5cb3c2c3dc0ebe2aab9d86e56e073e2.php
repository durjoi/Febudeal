<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Febudeal</title>

    <?php echo $__env->make('pertials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>
<body>
  <nav class="product__up__nav">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <a href="<?php echo e(route('product.catagory')); ?>"><i class="fas fa-arrow-left"></i></a>
          <h1>Febudeal</h1>
        </div>
      </div>
    </div>
  </nav>
  <div class="product__up__wrapper">
    <div class="wrapper__header">
      <h2>Post Your Ad</h2>
    </div>
    <div class="catagory__wrapper">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2>Select Sub Catagory <i class="fas fa-arrow-right"></i></h2>
            <p class="catagory_path"><?php echo e($catagory->catagory); ?></p>
            <ul>
              <?php $__currentLoopData = $subcatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('product.sub2catagory', $subcatagory->id)); ?>"><?php echo e($subcatagory->subcatagories); ?></a> </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

  </div>

  <?php echo $__env->make('pertials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/saler/salerProductSubcatagory.blade.php ENDPATH**/ ?>