<?php $__env->startSection('products'); ?>
  <div class="col-md-10">
    <div class="productsheader">
      <h3>Products</h3>
      <ul>
        <li> <a href="<?php echo e(route('saler.dashboard')); ?>">Live</a> </li>
        <li> <a href="<?php echo e(route('saler.pending')); ?>" class="active">Pending</a> </li>
        <li> <a href="#">Hold</a> </li>

      </ul>
    </div>



    
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="productsitem">
            <div class="item-top">
              <div class="row">
                <div class="col-md-6">
                  <h4>Product ID: <span><?php echo e($product->id); ?></span></h4>
                  <p class="orderdate"><?php echo e($product->updated_at); ?></p>
                </div>
                <div class="col-md-6 text-right">
                  <a href="/saler/product/<?php echo e($product->id); ?>">
                    <button type="button" name="button">Product Details</button>
                  </a>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <img src="<?php echo e(url('storage/products/'.$product->image1)); ?>" alt="">
                <h4 class="productname"><?php echo e($product->title); ?></h4>
                <p class="productprice"><span>Product Price:</span> <?php echo e($product->price); ?></p>
                <p class="productqty">Quantity: <?php echo e($product->quantity); ?> Pices</p>
                
                <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($catagory->id == $product->catagories_id): ?>
                    <?php $__currentLoopData = $subcatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($subcatagory->id == $product->subcatagories_id): ?>
                        <?php $__currentLoopData = $sub2catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($sub2catagory->id == $product->sub2catagories_id): ?>
                            <p class="productcatagory">
                              <?php echo e($catagory->catagory); ?> >
                              <?php echo e($subcatagory->subcatagories); ?> >
                              <?php echo e($sub2catagory->subcatagories2); ?>

                            </p>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </p>
              </div>
              <div class="col-md-6">
                <ul>
                  <li> <a href="#" class="edit"><i class="far fa-edit"></i> Edit</a> </li>
                  <li> <form class="" action="<?php echo e(route('product.delete', $product->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <i class="fas fa-trash-alt"></i><input type="submit" name="submit" value="Delete">
                  </li>
                  </form>
                  <li> <a href="#" class="archieve"><i class="fas fa-archive"></i> Archieve</a> </li>
                </ul>
              </div>
            </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

  


  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('saler.saler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/saler/salerPendingProducts.blade.php ENDPATH**/ ?>