<?php $__env->startSection('products'); ?>
  <div class="col-md-6 d-flex">
    <div class="nav-container">
      <div class="slider-nav">
        <div>
          <img src="<?php echo e(url('storage/products/'.$product->image1)); ?>" alt="">
        </div>
        <div>
          <img src="<?php echo e(url('storage/products/'.$product->image2)); ?>" alt="">
        </div>
        <div>
          <img src="<?php echo e(url('storage/products/'.$product->image3)); ?>" alt="">
        </div>
        <div>
          <img src="<?php echo e(url('storage/products/'.$product->image4)); ?>" alt="">
        </div>
      </div>
    </div>
      <div class="main-container">
        <div class="slider-main">
          <div>
            <img src="<?php echo e(url('storage/products/'.$product->image1)); ?>" alt="">
          </div>
          <div>
            <img src="<?php echo e(url('storage/products/'.$product->image2)); ?>" alt="">
          </div>
          <div>
            <img src="<?php echo e(url('storage/products/'.$product->image3)); ?>" alt="">
          </div>
          <div>
            <img src="<?php echo e(url('storage/products/'.$product->image4)); ?>" alt="">
          </div>
        </div>
      </div>




  </div>
  <div class="col-md-4">
    <div class="product__information">
      <p><?php echo e($catagory->catagory); ?>><?php echo e($subcatagory->subcatagories); ?>><?php echo e($sub2catagory->subcatagories2); ?></p>
      <h2><?php echo e($product->title); ?></h2>
      <p>Price: <?php echo e($product->price); ?> BDT</p>
      <p>Quantity: <?php echo e($product->quantity); ?></p>
      <h2>Description:</h2>
      <p><?php echo e($product->description); ?></p>
      <p><form class="" action="<?php echo e(route('product.delete', $product->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <i class="fas fa-trash-alt"></i><input type="submit" name="submit" value="Delete">
        </form></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('saler.saler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/saler/salerProduct.blade.php ENDPATH**/ ?>