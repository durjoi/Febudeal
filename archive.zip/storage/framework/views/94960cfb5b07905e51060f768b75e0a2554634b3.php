<?php $__env->startSection('content'); ?>
  <a href="<?php echo e(route('admin.catagory.add')); ?>">Add Catagory</a>
  <a href="<?php echo e(route('admin.subcatagory.add.catagory')); ?>">Add Sub Catagory</a>
  <a href="<?php echo e(route('admin.sub2catagory.add.catagory')); ?>">Add Sub Sub Catagory</a>
  <ul>
    <?php if(count($catagories)>0): ?>
      <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($catagory->catagory); ?>

          <form class="" action="<?php echo e(route('admin.catagory.delete', $catagory->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
          <input type="submit" name="delete" value="Delete">
        </form>
        <a href="<?php echo e(route('admin.catagory.edit', $catagory->id)); ?>">Edit</a>
          <ul>
              <?php if(count($subcatagories)>0): ?>
                <?php $__currentLoopData = $subcatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($subcatagory->catagories_id == $catagory->id): ?>
                    <li>
                        <?php echo e($subcatagory->subcatagories); ?>

                        <form class="" action="<?php echo e(route('admin.subcatagory.delete', $subcatagory->id)); ?>" method="post">
                          <?php echo csrf_field(); ?>
                        <input type="submit" name="delete" value="Delete">
                      </form>
                      <a href="<?php echo e(route('admin.subcatagory.edit', $subcatagory->id)); ?>">Edit</a>
                        <ul>
                          <?php if(count($sub2catagories)>0): ?>
                            <?php $__currentLoopData = $sub2catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($sub2catagory->subcatagories_id == $subcatagory->id): ?>
                                <li><?php echo e($sub2catagory->subcatagories2); ?>

                                  <form class="" action="<?php echo e(route('admin.sub2catagory.delete', $sub2catagory->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                  <input type="submit" name="delete" value="Delete">
                                </form>
                                <a href="<?php echo e(route('admin.sub2catagory.edit', $sub2catagory->id)); ?>">Edit</a>
                                </li>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </ul>
                      </li>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </ul>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminCatagory.blade.php ENDPATH**/ ?>