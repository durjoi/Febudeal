<div class="catagorynav">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">

        <ul class="catagorynav__mainlist">
          <?php if(count($catagories)>0): ?>
            <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="catagorynav__mainlist__item">
                <a href="#"><?php echo e($catagory->catagory); ?></a>
                
                <div class="catagory__dropdown">
                  <ul class="catagorynav__sublist">
                    <div class="container-fluid">
                      <div class="row">

                        <?php if(count($subcatagories)>0): ?>
                          <?php $__currentLoopData = $subcatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($subcatagory->catagories_id == $catagory->id): ?>
                              <div class="col-md-2">
                                <li class="sublist__item">
                                    <a href="#"><?php echo e($subcatagory->subcatagories); ?></a>
                                    <ul class="sublist__sublist">
                                      <?php if(count($sub2catagories)>0): ?>
                                        <?php $__currentLoopData = $sub2catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($sub2catagory->subcatagories_id == $subcatagory->id): ?>
                                            <li class="sublist__sublist__item">
                                              <a href="#"><?php echo e($sub2catagory->subcatagories2); ?></a>
                                            </li>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>
                                    </ul>
                                  </li>
                                  </div>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                      </div>
                    </div>
                  </ul>
                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>

</div>
<?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/layouts/catagoryNav.blade.php ENDPATH**/ ?>