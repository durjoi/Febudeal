<?php $__env->startSection('content'); ?>
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="prdcts__item text-center">
      <div class="img__container">
        <img src=<?php echo e(url('storage/products/'.$product->products_image)); ?> alt="#">
      </div>
      <h4><?php echo e($product->products_name); ?></h4>
      <p class="item__price"><?php echo e($product->price); ?> BDT</p>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/pages/CatagoryProductsPage.blade.php ENDPATH**/ ?>