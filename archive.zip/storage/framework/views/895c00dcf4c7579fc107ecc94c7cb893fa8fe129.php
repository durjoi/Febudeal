<?php $__env->startSection('content'); ?>
  <form class="catagoryUpdate" action="<?php echo e(route('admin.catagory.update', $catagory->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="catagory">Catagory Name</label>
    <input type="text" id="catagory" name="catagory" value="<?php echo e($catagory->catagory); ?>">
    <input type="submit" name="submit" value="submit">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminCatagoryEdit.blade.php ENDPATH**/ ?>