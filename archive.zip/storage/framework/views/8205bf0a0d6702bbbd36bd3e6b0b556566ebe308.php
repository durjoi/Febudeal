<?php $__env->startSection('content'); ?>
  <form class="catagoryUpdate" action="<?php echo e(route('admin.subcatagory.update', $subcatagory->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="subcatagory">Subcatagory Name</label>
    <input type="text" id="subcatagory" name="subcatagory" value="<?php echo e($subcatagory->subcatagories); ?>">
    <input type="submit" name="submit" value="submit">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminSubcatagoryEdit.blade.php ENDPATH**/ ?>