<?php $__env->startSection('content'); ?>
  <?php if(count($subcatagories)>0): ?>
    <ul>
      <?php $__currentLoopData = $subcatagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcatagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('admin.sub2catagory.add', $subcatagory->id)); ?>">
          <?php echo e($subcatagory->subcatagories); ?></a> </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminAddSub2catagorySubcatagory.blade.php ENDPATH**/ ?>