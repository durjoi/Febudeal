<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Febudeal</title>

    <?php echo $__env->make('pertials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>
<body>
  <nav class="product__up__nav">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <a href="<?php echo e(URL::previous()); ?>"><i class="fas fa-arrow-left"></i></a>
          <h1>Febudeal</h1>
        </div>
      </div>
    </div>
  </nav>
  <div class="product__up__form">
    <div class="wrapper__header">
      <h2>Post Your Ad</h2>
    </div>
    <div class="selected_catagory">
      <h2>Selected Catagory</h2>
      <p class="catagory__path">
        <?php echo e($catagory[0]->catagory); ?> > <?php echo e($subcatagory[0]->subcatagories); ?> >
        <?php echo e($sub2catagory->subcatagories2); ?>

      </p>
    </div>
    <div class="form__body">
      <h2>Add Some Details</h2>
      <form class="" action="<?php echo e(route('product.upload.product', $sub2catagory->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="title">Title</label><br>
        <input type="text" name="title" value="" id="title" required><br>
        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <label for="brand">Brand</label><br>
        <input type="text" name="brand" value="" id="brand" required><br>
        <?php if ($errors->has('brand')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('brand'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <label for="price">Price</label><br>
        <input type="text" name="price" value="" id="price" required><br>
        <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <label for="quantity">Quantity</label><br>
        <input type="text" name="quantity" value="" id="quantity" required><br>
        <?php if ($errors->has('quantity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantity'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <label for="description">Description</label><br>
        <textarea rows="20" cols="50" name="description" required></textarea><br>
        <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        



        <h4>Upload 4 Photos</h4>
        <input type="file" name="image1" required>
        <?php if ($errors->has('image1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image1'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <input type="file" name="image2" required>
        <?php if ($errors->has('image2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image2'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <input type="file" name="image3" required>
        <?php if ($errors->has('image3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image3'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <input type="file" name="image4" required><br>
        <?php if ($errors->has('image4')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image4'); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


        <input type="submit" name="submit" value="Post Now">

      </form>
    </div>
  </div>

  <?php echo $__env->make('pertials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/saler/salerProductUploadForm.blade.php ENDPATH**/ ?>