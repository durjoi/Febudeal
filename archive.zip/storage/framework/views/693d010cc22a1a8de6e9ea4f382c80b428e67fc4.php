<?php $__env->startSection('products'); ?>
  <div class="col-md-10">
    <div class="productsheader">
      <h3>Products</h3>
      <ul>
        <li> <a href="<?php echo e(route('saler.dashboard')); ?>" class="active">Live</a> </li>
        <li> <a href="<?php echo e(route('saler.pending')); ?>">Pending</a> </li>
        <li> <a href="">Hold</a> </li>

      </ul>
    </div>

    <?php if(count($products)>0): ?>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="productsitem">
            <div class="item-top">
              <div class="row">
                <div class="col-md-6">
                  <h4>Product ID: <span><?php echo e($product->id); ?></span></h4>
                  <p class="orderdate"><?php echo e($product->updated_at); ?></p>
                </div>
                <div class="col-md-6 text-right">
                  <a href="/saler/product/<?php echo e($product->id); ?>">
                    <button type="button" name="button">Product Details</button>
                  </a>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <img src="<?php echo e(url('storage/products/'.$product->products_image)); ?>" alt="">
                <h4 class="productname"><?php echo e($product->products_name); ?></h4>
                <p class="productprice"><span>Product Price:</span> <?php echo e($product->price); ?></p>
                <p class="productqty">Quantity: <?php echo e($product->quantity); ?> Pices</p>
                <p class="productqty">Catagory: <?php echo e($product->catagory); ?></p>
              </div>
              <div class="col-md-6">
                <ul>
                  <li> <a href="#" class="edit"><i class="far fa-edit"></i> Edit</a> </li>
                  <li> <a href="#" class="delete"><i class="fas fa-trash-alt"></i> Delete</a> </li>
                  <li> <a href="#" class="archieve"><i class="fas fa-archive"></i> Archieve</a> </li>
                </ul>
              </div>
            </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      <p>No Products Found</p>

    <?php endif; ?>


  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('saler.saler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/saler/salerLiveProducts.blade.php ENDPATH**/ ?>