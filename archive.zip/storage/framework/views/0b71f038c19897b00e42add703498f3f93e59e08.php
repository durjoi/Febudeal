<?php $__env->startSection('products'); ?>
  <div class="col-md-10">
    <form class="upload" action="<?php echo e(route('product.upload.submit')); ?>" method="post" enctype="multipart/form-data">

      <?php echo csrf_field(); ?>
      <label for="products_name">Products Name: </label>
      <input type="text" name="products_name" id="products_name" required>
      <?php if ($errors->has('products_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('products_name'); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      <label for="info">Products Description: </label>
      <input type="text" name="info" id="info" required>
      <?php if ($errors->has('info')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('info'); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      <label for="quantity">Quantity: </label>
      <input type="text" name="quantity" id="quantity" required>
      <?php if ($errors->has('quantity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantity'); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      <label for="price">Price: </label>
      <input type="text" name="price" id="price" required>
      <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      <label for="price">Img: </label>
      <input type="file" name="image" id="image" required>
      <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      <label for="catagory">Catagory: </label>
      <input type="text" name="catagory" id="catagory" value="<?php echo e($catagory); ?>" required>
      <?php if ($errors->has('catagory')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catagory'); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      <button type="submit" name="button">Submit</button>

    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('saler.saler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/saler/salerUploadProduct.blade.php ENDPATH**/ ?>