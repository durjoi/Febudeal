<?php $__env->startSection('content'); ?>
  <?php if(count($catagories)>0): ?>
    <ul>
      <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('admin.subcatagory.add', $catagory->id)); ?>"><?php echo e($catagory->catagory); ?></a> </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminAddSubcatagoryCatagory.blade.php ENDPATH**/ ?>