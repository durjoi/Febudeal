<?php $__env->startSection('content'); ?>
  <form class="addSub2catagory" action="<?php echo e(route('admin.sub2catagory.add', $id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="sub2catagory">Sub Catagory Name</label>
    <input type="text" id="sub2catagory" name="sub2catagory" value="">
    
    <input type="submit" name="submit" value="submit">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/febudeal/resources/views/admin/adminAddSub2catagory.blade.php ENDPATH**/ ?>