@extends('layouts.master')

@section('content')
    Hello
@endsection
